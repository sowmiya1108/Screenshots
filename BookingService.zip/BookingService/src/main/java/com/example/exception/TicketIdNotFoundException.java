package com.example.exception;

public class TicketIdNotFoundException extends Exception{

	public TicketIdNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TicketIdNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TicketIdNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TicketIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TicketIdNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
