package com.trainsearch.exception;

@SuppressWarnings("serial")
public class TrainIdNotFoundException extends Exception
{

	public TrainIdNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrainIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TrainIdNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
